var Queries = function(){
  	
};

Queries.prototype.selectUserQuery = function(userId){
	//return "Select * from user where user_id ='"+ dion_scheme_code +"'";
};